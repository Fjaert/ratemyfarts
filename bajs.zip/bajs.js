let currentAudio = null;

function playFart() {
const fileInput = document.getElementById('fartUpload');
const player = document.getElementById('fartPlayer');

if (fileInput.files.length === 0) {
alert("Please upload a fart sound first!");
return;
}

const file = fileInput.files[0];
const url = URL.createObjectURL(file);
player.src = url;
player.style.display = "block";
player.play();
}

function rateFart(score) {
alert(`You rated this fart a ${score}/10! Thanks for your honesty.`);
// Future: Send to server/database
}